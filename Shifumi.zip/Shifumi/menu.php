<?php
function showMenu()
{
    echo "\n=== Menu Principal ===\n";
    echo "1. Nouvelle Partie\n";
    echo "2. Consulter l'historique\n";
    echo "3. Consulter les statistiques\n";
    echo "4. Quitter\n";
    echo "Choix : ";
}
